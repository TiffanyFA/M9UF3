import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Sortida implements Runnable {
	private Socket socket;
	private PrintWriter[] canalSortida;
	private String[] noms;

	public Sortida(Socket socket, PrintWriter[] canalSortida, String[] noms) {
		this.socket = socket;
		this.canalSortida = canalSortida;
		this.noms = noms;
	}

	@Override
	public void run() {
		String eco = "";
		// FLUX D'ENTRADA AL SERVIDOR
		BufferedReader fentrada;
		try {
			fentrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));

			eco = fentrada.readLine();
			while (true && eco != null) {

				for (int i = 0; i < canalSortida.length; i++) {
					// Rebuda cadena del servidor
					if (canalSortida[i] != null) {

						canalSortida[i].println("  =>ECO: " + eco);
					}
				}
				eco = fentrada.readLine();

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
