import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client {

	public static void main(String[] args) {

		String host = "localhost";
		int port = 60000;// Port remot
		Socket client;
		try {
			client = new Socket(host, port);

			Entrada entrada;
			
			// FLUX DE SORTIDA AL SERVIDOR
			PrintWriter fsortida = new PrintWriter(client.getOutputStream(),
					true);

			// FLUX D'ENTRADA AL SERVIDOR
			BufferedReader fentrada = new BufferedReader(new InputStreamReader(
					client.getInputStream()));

			// FLUX PER A ENTRADA EST�NDARD
			BufferedReader in = new BufferedReader(new InputStreamReader(
					System.in));

			String cadena = "";
			System.out.println("Introdueix el teu nom: ");
			cadena = in.readLine();
			// Enviament cadena al servidor
			fsortida.println(cadena);
			System.out
					.println("Introdueix la cadena (0 per a tots, 1 per a un client): ");

			// Lectura teclat
			cadena = in.readLine();

			entrada = new Entrada(fentrada);
			Thread thread = new Thread(entrada);
			thread.start();

			while (cadena != null && (!(cadena.equals("*")))) {

				// Enviament cadena al servidor
				fsortida.println(cadena);
				// Lectura del teclat
				cadena = in.readLine();

			}
			
			cadena = "Client desconnectat";
			fsortida.println(cadena);
			entrada.atura();			
			fentrada.close();
			fsortida.close();
			in.close();
			client.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
