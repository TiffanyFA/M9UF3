import java.io.BufferedReader;
import java.io.IOException;

public class Entrada implements Runnable {
	// private Socket socket;
	private BufferedReader fentrada;
	boolean parar = false;

	public Entrada(BufferedReader fentrada) {
		// this.socket = socket;
		this.fentrada = fentrada;
	}

	@Override
	public void run() {

		String s;
		try {
			s = fentrada.readLine();
			while ((s != null) && (!parar)) {
				System.out.println(s);
				s = fentrada.readLine();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void atura() {
		this.parar = true;
	}
}
