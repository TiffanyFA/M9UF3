import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Scanner;

public class ServidorTCP4 {
	public static int comptaClients = 0;

	public static void main(String[] args) throws Exception {

		Scanner teclat = new Scanner(System.in);
		int numPort = 60000;
		ServerSocket servidor = new ServerSocket(numPort);
		int limit;
		Thread thread;
		PrintWriter[] canalSortida;
		Sortida filSortida;
		String[] noms;
		BufferedReader fentrada = null;

		// demanar l�mit
		System.out.println("Quants clients puc atendre? ");
		limit = teclat.nextInt();
		canalSortida = new PrintWriter[limit];
		noms = new String[limit];

		// servir� als clients mentre el nombre de clients no superi el l�mit entrat per
		// par�metre
		while (comptaClients < limit) {
			try {
				System.out.println("Esperant connexi�... ");
				Socket clientConnectat = servidor.accept();
				fentrada = new BufferedReader(new InputStreamReader(clientConnectat.getInputStream()));
				noms[comptaClients] = fentrada.readLine();
				canalSortida[comptaClients] = new PrintWriter(clientConnectat.getOutputStream(), true);
				filSortida = new Sortida(clientConnectat, canalSortida, noms);
				// comptador de clients connectats
				comptaClients++;
				thread = new Thread(filSortida, ("Client " + noms[comptaClients]));
				thread.start();

			} catch (SocketException s) {
				System.out.println("ERROR en la connexi�");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		servidor.close();
		teclat.close();

	}

}
