import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;


public class Sortida extends ServidorTCP4 implements Runnable {
	private Socket socket;
	private PrintWriter[] canalSortida;
	private String[] noms;
	
	public Sortida(Socket socket, PrintWriter[] canalSortida, String[] noms) {
		this.socket = socket;
		this.canalSortida = canalSortida;
		this.noms = noms;
	}
	@Override
	public void run() {
		String eco = "";
		// FLUX D'ENTRADA AL SERVIDOR
		BufferedReader fentrada;
		String[] parts;
		String opcio;
		String nom;
		try {
			fentrada = new BufferedReader(new InputStreamReader(
					socket.getInputStream()));
					
			eco = fentrada.readLine();
			
			while (true && eco!=null) { 
				parts = eco.split("-");
				opcio = parts[0];
				
				if (opcio.equals("0")) {
					for (int i = 0; i < canalSortida.length; i++) {
						for (int j = 0; j < noms.length; j++) {
							if(canalSortida[i] != null){
								canalSortida[i].println(noms[i]);
							}
						}
					}
				} else if (opcio.equals("1")) {					
					for (int i = 0; i < canalSortida.length; i++) {
						// Rebuda cadena del servidor
						if(canalSortida[i] != null){
							canalSortida[i].println("  =>ECO: " + eco);
						}
					}
					eco = fentrada.readLine();
				} else {
					nom = parts[1];
					eco = parts[2];
					for (int i = 0; i < noms.length; i++) {
						if (noms[i].equalsIgnoreCase(nom)) {
							canalSortida[i].println("  =>ECO: " + eco);
						}
					}
					eco = fentrada.readLine();
				}
				 
			}
			comptaClients--;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
}
